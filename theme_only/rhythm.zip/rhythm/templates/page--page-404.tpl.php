<?php
/**
 * @file
 * Default theme implementation to display a single Drupal page.
 *
 * Available variables:
 *
 * General utility variables:
 * - $base_path: The base URL path of the Drupal installation. At the very
 *   least, this will always default to /.
 * - $directory: The directory the template is located in, e.g. modules/system
 *   or themes/garland.
 * - $is_front: TRUE if the current page is the front page.
 * - $logged_in: TRUE if the user is registered and signed in.
 * - $is_admin: TRUE if the user has permission to access administration pages.
 *
 * Site identity:
 * - $front_page: The URL of the front page. Use this instead of $base_path,
 *   when linking to the front page. This includes the language domain or
 *   prefix.
 * - $logo: The path to the logo image, as defined in theme configuration.
 * - $site_name: The name of the site, empty when display has been disabled
 *   in theme settings.
 * - $site_slogan: The slogan of the site, empty when display has been disabled
 *   in theme settings.
 *
 * Navigation:
 * - $main_menu (array): An array containing the Main menu links for the
 *   site, if they have been configured.
 * - $secondary_menu (array): An array containing the Secondary menu links for
 *   the site, if they have been configured.
 * - $breadcrumb: The breadcrumb trail for the current page.
 *
 * Page content (in order of occurrence in the default page.tpl.php):
 * - $title_prefix (array): An array containing additional output populated by
 *   modules, intended to be displayed in front of the main title tag that
 *   appears in the template.
 * - $title: The page title, for use in the actual HTML content.
 * - $title_suffix (array): An array containing additional output populated by
 *   modules, intended to be displayed after the main title tag that appears in
 *   the template.
 * - $messages: HTML for status and error messages. Should be displayed
 *   prominently.
 * - $tabs (array): Tabs linking to any sub-pages beneath the current page
 *   (e.g., the view and edit tabs when displaying a node).
 * - $action_links (array): Actions local to the page, such as 'Add menu' on the
 *   menu administration interface.
 * - $feed_icons: A string of all feed icons for the current page.
 * - $node: The node object, if there is an automatically-loaded node
 *   associated with the page, and the node ID is the second argument
 *   in the page's path (e.g. node/12345 and node/12345/revisions, but not
 *   comment/reply/12345).
 *
 * Regions:
 * - $page['help']: Dynamic help text, mostly for admin pages.
 * - $page['content']: The main content of the current page.
 * - $page['sidebar_first']: Items for the first sidebar.
 * - $page['sidebar_second']: Items for the second sidebar.
 * - $page['header']: Items for the header region.
 * - $page['footer']: Items for the footer region.
 *
 * @see template_preprocess()
 * @see template_preprocess_page()
 * @see template_process()
 */
?>
<div class="js-height-full">
    <div class="home-content container">
        <div class="home-text">
            <div class="hs-cont">
                
                <!-- Headings -->
                <div class="hs-wrap">
                    
                    <div class="hs-line-13 font-alt mb-10">
                        404
                    </div>
                    
                    <div class="hs-line-4 font-alt mb-40">
                        <?php print t('The page you were looking for could not be found.'); ?>
                    </div>
                    
                    <div class="local-scroll">                                        
                        <a href="<?php print url('<front>'); ?>" class="btn btn-mod btn-w btn-round btn-small"><i class="fa fa-angle-left"></i> <?php print t('Back To Home Page'); ?></a>                                        
                    </div>
                    
                </div>
                <!-- End Headings -->
                
            </div>
        </div>
    </div>
    <!-- End Hero Content -->
    
</div>

<nav class="main-nav dark stick-fixed js-transparent small-height">
    <div class="full-wrapper relative clearfix">
        <div class="nav-logo-wrap local-scroll">
            <a href="<?php print url('<front>'); ?>" class="logo small-height">
                <img src="<?php print theme_get_setting('logo'); ?>" alt="">
            </a>
        </div>
        <div class="mobile-nav small-height" style="height: 75px; line-height: 75px; width: 75px;">
            <i class="fa fa-bars"></i>
        </div>
        <div class="inner-nav desktop-nav">
            <ul class="clearlist scroll-nav local-scroll">
              <li class="active"><a href="mailto:<?php print variable_get('site_mail'); ?>" style="height: 75px; line-height: 75px;"><i class="fa fa-envelope"></i> <?php print variable_get('site_mail'); ?></a></li>
              <?php if(theme_get_setting('phone')): ?>
                <li><a href="#" style="height: 75px; line-height: 75px;"><i class="fa fa-phone"></i> <?php print theme_get_setting('phone'); ?></a></li>                
              <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>