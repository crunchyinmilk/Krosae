<hr class="mt-0 mb-0 ">
<div class="work-navigation clearfix">
  <a href="<?php print url('node/' . $prev); ?>" class="work-prev"><span><i class="fa fa-chevron-left"></i>&nbsp;<?php print t('Previous'); ?></span></a>
  <a href="<?php print url($all_works); ?>" class="work-all"><span><i class="fa fa-times"></i>&nbsp;<?php print t('All works'); ?></span></a>
  <a href="<?php print url('node/' . $next); ?>" class="work-next"><span><?php print t('Next'); ?>&nbsp;<i class="fa fa-chevron-right"></i></span></a>
</div>